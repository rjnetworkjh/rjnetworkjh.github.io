# RJ NETWORK — ZIP Upload Auto Extract

এখন থেকে এই repository-তে নতুন ফিচারের ZIP ফাইল `uploads/` ফোল্ডারে আপলোড করলে GitHub Actions সেটি স্বয়ংক্রিয়ভাবে Extract করে website root-এ যুক্ত করবে।

## একবারের GitHub সেটআপ

1. এই আপডেটেড ZIP Extract করে এর সব ফাইল আপনার `rjnetworkjh.github.io` repository-র `main` branch-এ আপলোড/commit করুন।
2. GitHub Repository → **Settings → Actions → General** খুলুন।
3. **Workflow permissions** অংশে **Read and write permissions** নির্বাচন করে Save করুন।
4. Repository → **Settings → Pages**-এ গিয়ে নিশ্চিত করুন Build and deployment source হলো **Deploy from a branch**, branch `main`, folder `/ (root)` (আপনার বর্তমান Pages configuration আলাদা হলে সেটি অপরিবর্তিত রাখুন)।

## নতুন ফিচার আপলোড করার নিয়ম

1. Repository-তে `uploads/` ফোল্ডার খুলুন।
2. **Add file → Upload files** নির্বাচন করুন।
3. নতুন ফিচারের `.zip` ফাইলটি আপলোড করুন।
4. Commit changes করুন।
5. **Actions → ZIP Upload Auto Extract → latest run** খুলে কাজ সফল হয়েছে কি না দেখুন।
6. সফল হলে ZIP-এর ফাইলগুলো website root-এ Extract হবে, ZIP ফাইলটি `uploads/` থেকে মুছে যাবে এবং GitHub Actions নিজে একটি commit করবে।
7. GitHub Pages branch deployment সক্রিয় থাকলে এরপর সাইট আপডেট হবে।

## ZIP-এর ভেতরের গঠন

সাধারণ ফিচার ZIP:
```text
index.html
assets/
  feature.css
  feature.js
```

GitHub-এর **Download ZIP**-এর মতো একটি মাত্র wrapper folder থাকলেও workflow সেটি স্বয়ংক্রিয়ভাবে বাদ দিয়ে ভেতরের ফাইলগুলো root-এ Extract করার চেষ্টা করবে।

## গুরুত্বপূর্ণ নিরাপত্তা ও সীমা

- `.git`, `.github`, `uploads`, `node_modules`-এ Extract করা নিষিদ্ধ; বিদ্যমান workflow overwrite হবে না।
- ZIP path traversal ও symbolic link ব্লক করা হয়।
- প্রতি ZIP-এ সর্বোচ্চ ৫,০০০টি entry এবং ৫০০ MB uncompressed data অনুমোদিত।
- ZIP ফাইলের মধ্যে `index.html`, `style.css`, `products.js` বা অন্য বিদ্যমান ফাইল থাকলে সেগুলো overwrite হতে পারে। আগে backup/branch ব্যবহার করুন।
- শুধু বিশ্বস্ত ZIP আপলোড করুন।
- এই সিস্টেম ZIP-এর ভেতরের ফাইল Extract করে; ZIP নিজে থেকে নতুন ফিচার তৈরি করে না।
- Workflow `main` branch-এর জন্য কনফিগার করা। অন্য branch ব্যবহার করলে workflow ফাইলে branch নাম পরিবর্তন করতে হবে।

## Workflow কোথায় পাবেন?

`.github/workflows/zip-upload-auto-extract.yml`
